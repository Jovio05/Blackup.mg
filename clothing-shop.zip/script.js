const products = [
  { id: 1, name: "T-shirt noir", price: 20, image: "images/produit1.jpg" },
  { id: 2, name: "Jean slim", price: 45, image: "images/produit2.jpg" },
  { id: 3, name: "Sweat oversize", price: 35, image: "images/produit3.jpg" }
];

function displayProducts() {
  const container = document.getElementById('product-list');
  if (!container) return;

  products.forEach(product => {
    const div = document.createElement('div');
    div.className = "product";
    div.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>${product.price} €</p>
      <button onclick="addToCart(${product.id})">Ajouter au panier</button>
    `;
    container.appendChild(div);
  });
}

function addToCart(id) {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const product = products.find(p => p.id === id);
  const found = cart.find(p => p.id === id);

  if (found) {
    found.quantity++;
  } else {
    cart.push({ ...product, quantity: 1 });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  alert("Ajouté au panier !");
}

function displayCart() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const container = document.getElementById('cart-items');
  const totalContainer = document.getElementById('total');
  if (!container || !totalContainer) return;

  container.innerHTML = "";
  let total = 0;

  cart.forEach(item => {
    const div = document.createElement('div');
    div.innerHTML = `
      <p>${item.name} - ${item.quantity} x ${item.price} €</p>
      <button onclick="removeFromCart(${item.id})">Supprimer</button>
    `;
    container.appendChild(div);
    total += item.quantity * item.price;
  });

  totalContainer.textContent = "Total: " + total + " €";
}

function removeFromCart(id) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart = cart.filter(p => p.id !== id);
  localStorage.setItem('cart', JSON.stringify(cart));
  displayCart();
}

function clearCart() {
  localStorage.removeItem('cart');
  displayCart();
}

document.addEventListener("DOMContentLoaded", () => {
  displayProducts();
  displayCart();
});